import { TODAY } from './core.js';
import { announce } from './core.js';
// ═════════════════════════════════════════════════════════════════
// SCREENSHOT MODULE — Daily Structure Tracker
// ═════════════════════════════════════════════════════════════════

// ── QR import (scan from camera — future feature placeholder) ─────────────
// Full camera-based QR scanning requires getUserMedia + a QR decoder library.
// For now, users scan the QR with their new device's camera app which opens
// a URL or shows the JSON — they can then copy/paste into a text file and import.
// TODO: add jsQR library for in-app camera scanning.


// ── Re-exports — app.js imports these from screenshot.js ────────────
export { takePhoto, closePreview } from './state.js';
export { savePreviewImage, changeSaveFolder } from './accessibility.js';
